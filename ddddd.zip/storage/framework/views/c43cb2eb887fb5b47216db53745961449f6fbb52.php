<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2023 - <?php echo e(date('Y')); ?> &copy; NPS by <a href="https://riseuplabs.com/" target="_blank">Riseup Labs</a>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
<?php /**PATH /var/www/html/nps-calculator/resources/views/admin/inc/footer.blade.php ENDPATH**/ ?>