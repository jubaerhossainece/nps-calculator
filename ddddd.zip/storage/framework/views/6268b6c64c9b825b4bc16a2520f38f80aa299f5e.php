<?php $__env->startSection('page-title', 'Sign In to NPS'); ?>
<?php $__env->startSection('form-title','Sign In to NPS'); ?>
<?php $__env->startSection('content'); ?>

    <form action="#" method="post" class="p-3">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="form-group mb-4">
            <div class="input-group">
                <input type="email" name="email" class="form-control" placeholder="Enter Email" required="">
                <span class="input-group-append"> <button type="submit" class="btn btn-primary waves-effect waves-light">Reset</button> </span>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-sm-7">
                <a href="<?php echo e(route('login')); ?>"><i class="fa mr-1"></i> Log in</a>
            </div>
            
            
            
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/nps-calculator/resources/views/admin/auth/forgot-password.blade.php ENDPATH**/ ?>