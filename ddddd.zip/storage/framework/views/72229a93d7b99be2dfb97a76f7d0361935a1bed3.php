<?php $__env->startSection('page-title', 'Sign In to NPS'); ?>
<?php $__env->startSection('form-title','Sign In to NPS'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('login')); ?>" method="post" class="p-3">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-3">
            <input class="form-control" name="email" type="email" required="" placeholder="Email">
        </div>

        <div class="form-group mb-3">
            <input class="form-control" name="password" type="password" required="" placeholder="Password">
        </div>

        <div class="form-group mb-3">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" name="remember" class="custom-control-input" id="checkbox-signin">
                <label class="custom-control-label" for="checkbox-signin">Remember me</label>
            </div>
        </div>

        <div class="form-group text-center mt-5 mb-4">
            <button class="btn btn-primary waves-effect width-md waves-light" type="submit"> Log
                In
            </button>
        </div>

        <div class="form-group row mb-0">
            <div class="col-sm-7">
                <a href="<?php echo e(route('password.request')); ?>"><i class="fa fa-lock mr-1"></i> Forgot your password?</a>
            </div>
            
            
            
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/nps-calculator/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>