@extends('admin.layouts.app')
@push('styles')

@endpush

@section('content')
    <div class="container mt-5 mb-5">
        <div class="row justify-content-center">
            
        </div>
    </div>
        
@endsection

@push('scripts')
<script>
    
</script>
@endpush
