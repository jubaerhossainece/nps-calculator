<?php

return [
    'frontend_app_url' => 'http://192.168.10.156:9000/',
    'shareable_app_url' => 'http://192.168.10.156:9000/shareable-link/',
];
